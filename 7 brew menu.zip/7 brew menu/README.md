# 7 Brew - Neon Coffee Lab Suite

This workspace contains two distinct projects matching the premium futuristic **"Neon Coffee Lab"** design theme:

1. **`caffeine-calculator/`**: The main browser extension popup for calculating caffeine and calories.
2. **`neon-coffee-lab-theme/`**: A matching browser theme that styles the window borders, toolbar, URL bar, active tabs, and icon tints in deep espresso and glowing electric blue.

---

## 📁 Repository Structure

```text
7 brew menu/
│
├── caffeine-calculator/        # Main Browser Extension Project
│   ├── chrome/                 # Compiled Chrome Extension
│   ├── edge/                   # Compiled Edge Extension
│   ├── firefox/                # Compiled Firefox Extension
│   ├── shared/                 # Master Source Files (HTML, CSS, JS, Assets)
│   ├── sync.py                 # Synchronization Script
│   └── generate_icons.py       # Icon Generation Script
│
├── neon-coffee-lab-theme/      # Matching Browser Theme Project
│   ├── chrome/                 # Chrome Theme Manifest
│   ├── edge/                   # Edge Theme Manifest
│   └── firefox/                # Firefox Theme Manifest
│
└── README.md                   # This Workspace Overview
```

---

## 🚀 Projects Overview & Setup

### 1. Caffeine Calculator Extension (`caffeine-calculator/`)
A dashboard extension to estimate caffeine, calories, and energy levels for 7 Brew drinks.
- **Development**: Edit files in `caffeine-calculator/shared/` and run `python sync.py` inside the `caffeine-calculator/` directory to build.
- **Loading**:
  - Chrome/Edge: Load unpacked extension selecting the `caffeine-calculator/chrome/` (or `/edge/`) folder.
  - Firefox: Load temporary add-on selecting the `manifest.json` in `caffeine-calculator/firefox/`.

### 2. Neon Coffee Lab Theme (`neon-coffee-lab-theme/`)
A matching dark browser theme to complete the cyber-tech look.
- **Colors**: Deep espresso toolbar (`#161920`), frame black background (`#0f1115`), URL input card (`#12141a`), active tab cream texts, and electric neon blue browser controls (`#00c2ff`).
- **Loading**:
  - Chrome/Edge: Load unpacked extension selecting the `neon-coffee-lab-theme/chrome/` (or `/edge/`) folder.
  - Firefox: Load temporary add-on selecting the `manifest.json` in `neon-coffee-lab-theme/firefox/`.
