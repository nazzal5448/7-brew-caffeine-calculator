# 7 Brew Caffeine Calculator Extension - Neon Coffee Lab Edition

A lightweight, modern, and highly polished cross-browser extension for Chrome, Edge, and Firefox. It helps users quickly estimate caffeine, calories, and energy levels for popular signature 7 Brew drinks with support for custom sizes, extra espresso shots, search filtering, and saving favorite drinks.

This version features the premium **"Neon Coffee Lab"** design theme, styled like a futuristic coffee-tech cockpit.

---

## 🚀 Features

- **Futuristic Cyber-Tech Dashboard**: Styled with a dark mode glassmorphic panel, neon glow accents, tactile controls, and smooth micro-animations.
- **Animated Circular Energy Gauge**: An interactive circular gauge showing energy status tiers:
  - **LOW**: Soft neon teal glow (`#00ffcc`)
  - **MODERATE**: Warm amber glow (`#ffb347`)
  - **HIGH**: Vibrant neon orange glow (`#ff8c42`)
  - **EXTREME**: Pulse-animated neon red glow (`#ff0055`)
- **Drink Selection & Search**: Search and select from a realistic database of 7 Brew drinks (Blondie, Brunette, Smooth 7, White Chocolate Mocha, Caramel Macchiato, Cinnamon Roll, Energy Drink, and Cold Brew).
- **Responsive Serving Volumes**: Select between Small (16 oz), Medium (24 oz), and Large (32 oz) sizes.
- **Espresso Charge Additions**: Inject up to 2 extra shots of espresso. The calculator dynamically scales both caffeine (+75mg per shot) and calories (+5 kcal per shot) with real-time meter transitions.
- **Live System Metrics**: Left/right metrics cards with real-time progress indicators tracking caffeine load (mg) and calorie count (kcal) against FDA daily recommended maximum values (400mg).
- **Favorites Storage**: Save custom orders (drink, size, shots) using browser storage (`chrome.storage.local` with fallback to `localStorage`). Load them instantly as quick-tap hologram pills.
- **System Actions**:
  - **⚡ OVERLOAD**: Instant-load configuration with maximum caffeine potential (Large Cold Brew with 2 extra shots).
  - **🌱 ZERO-CAL**: Instantly filter the formula list to show options that are low-calorie (< 150 kcal for a Small).

---

## 📁 Folder Structure

The project is structured to maximize code reusability using a **Shared-Code Architecture**. The source code is written in `shared/`, and a python sync script automatically populates browser-specific directories with their respective builds.

```text
7 brew menu/
│
├── chrome/             # Compiled Chrome Extension folder (Load Unpacked)
│   ├── manifest.json   # Manifest V3 (Chrome & Chromium engines)
│   ├── assets/         # Bundled neon icons (16px, 32px, 48px, 128px)
│   ├── data/           # Drinks database
│   ├── logic/          # Calculation engine
│   └── popup/          # Popup UI HTML, CSS, JS
│
├── edge/               # Compiled Microsoft Edge Extension folder
│   ├── manifest.json   # Manifest V3 (Edge compatible)
│   ├── assets/
│   ├── data/
│   ├── logic/
│   └── popup/
│
├── firefox/            # Compiled Firefox Add-on folder (Load Temporary Add-on)
│   ├── manifest.json   # Firefox compatible Manifest V3 (with Gecko configuration)
│   ├── assets/
│   ├── data/
│   ├── logic/
│   └── popup/
│
├── shared/             # Source code folder (Do edits here!)
│   ├── assets/         # Master icon assets
│   ├── data/           # Master drinks.json
│   ├── logic/          # Master calculator.js
│   └── popup/          # Master popup.html, popup.css, popup.js
│
├── sync.py             # Python sync utility script
├── generate_icons.py   # Icon generation utility script
└── README.md           # This instructions manual
```

---

## 🛠️ Development & Synchronization

All common layout, style, database, and logic files reside in the `shared/` directory.

### Syncing Changes to Browsers
If you modify any file in `shared/`, you need to copy the updated files to the browser-specific folders (`chrome`, `edge`, `firefox`). 

We've provided a simple, cross-platform synchronization script in Python:

1. Open a terminal/command prompt in this project directory.
2. Run the sync script:
   ```bash
   python sync.py
   ```
This script will copy all code and resources from `shared/` to `chrome/`, `edge/`, and `firefox/` automatically.

### Regenerating Icons
The extension icons (custom neon electric blue "7" emblem on a charcoal black background) are generated programmatically. If you want to modify the icon design:
1. Edit the canvas drawing coordinates in `generate_icons.py`.
2. Run:
   ```bash
   python generate_icons.py
   ```
3. Run `python sync.py` to distribute the updated icons to all browser directories.

---

## 🔌 Browser Loading Instructions

To run the extension locally in your preferred browser, follow these steps:

### 1. Google Chrome / Chromium-Based Browsers
1. Open Google Chrome.
2. In the URL bar, go to `chrome://extensions/`.
3. Enable **Developer mode** using the toggle switch in the top-right corner.
4. Click the **Load unpacked** button in the top-left corner.
5. Select the `chrome/` folder from this project directory.
6. The extension is now loaded! Click the Extension puzzle icon in your toolbar to pin it.

### 2. Microsoft Edge
1. Open Microsoft Edge.
2. In the URL bar, go to `edge://extensions/`.
3. Enable the **Developer mode** toggle in the bottom-left pane.
4. Click the **Load unpacked** button.
5. Select the `edge/` folder from this project directory.
6. Pin the extension to your toolbar to access it.

### 3. Mozilla Firefox
1. Open Mozilla Firefox.
2. In the URL bar, go to `about:debugging#/runtime/this-firefox`.
3. Click the **Load Temporary Add-on...** button.
4. Navigate to the `firefox/` folder and select the `manifest.json` file inside it.
5. The extension will remain loaded until you restart Firefox.

---

## 📊 Core Calculation Reference

- **Espresso Shot additions**:
  - **Caffeine**: `+75 mg` per shot
  - **Calories**: `+5 kcal` per shot
- **Energy Categories**:
  - **Low**: `< 100 mg` (Safe/soft energy level)
  - **Moderate**: `100 mg – 199 mg` (Equivalent to a standard cup of coffee or energy drink)
  - **High**: `200 mg – 349 mg` (Substantial concentration, alert levels)
  - **Extreme**: `≥ 350 mg` (Close to FDA daily maximum of 400mg)
