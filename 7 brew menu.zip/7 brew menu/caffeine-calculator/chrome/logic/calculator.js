/**
 * 7 Brew Caffeine Calculator Logic
 */

// Constants for additions
const ESPRESSO_SHOT_CAFFEINE = 75; // mg per shot
const ESPRESSO_SHOT_CALORIES = 5;  // kcal per shot

/**
 * Categorize energy level based on caffeine content
 * @param {number} caffeine - Caffeine content in mg
 * @returns {string} - 'Low' | 'Moderate' | 'High' | 'Extreme'
 */
export function getEnergyLevel(caffeine) {
  if (caffeine < 100) {
    return 'Low';
  } else if (caffeine < 200) {
    return 'Moderate';
  } else if (caffeine < 350) {
    return 'High';
  } else {
    return 'Extreme';
  }
}

/**
 * Calculate the total caffeine and calories for a drink configuration
 * @param {Object} drink - The drink object from drinks.json
 * @param {string} sizeKey - 'small' | 'medium' | 'large'
 * @param {number} extraShots - Number of extra espresso shots (0, 1, 2)
 * @returns {Object} - { caffeine: number, calories: number, energyLevel: string }
 */
export function calculateCaffeineAndCalories(drink, sizeKey, extraShots = 0) {
  if (!drink || !drink.sizes || !drink.sizes[sizeKey]) {
    return { caffeine: 0, calories: 0, energyLevel: 'Low' };
  }

  const baseData = drink.sizes[sizeKey];
  let totalCaffeine = baseData.caffeine;
  let totalCalories = baseData.calories;

  // Add extra shots logic
  if (extraShots > 0) {
    totalCaffeine += extraShots * ESPRESSO_SHOT_CAFFEINE;
    totalCalories += extraShots * ESPRESSO_SHOT_CALORIES;
  }

  return {
    caffeine: totalCaffeine,
    calories: totalCalories,
    energyLevel: getEnergyLevel(totalCaffeine)
  };
}
