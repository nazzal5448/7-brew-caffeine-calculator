/**
 * 7 Brew Caffeine Calculator Popup Controller - NEON COFFEE LAB Edition
 */

import { calculateCaffeineAndCalories } from '../logic/calculator.js';

// Elements
const drinkSearch = document.getElementById('drink-search');
const dropdownArrow = document.getElementById('dropdown-arrow');
const drinksDropdown = document.getElementById('drinks-dropdown');
const sizeControl = document.getElementById('size-control');
const shotsControl = document.getElementById('shots-control');
const favoriteToggle = document.getElementById('favorite-toggle');
const favoritesSection = document.getElementById('favorites-section');
const favoritesList = document.getElementById('favorites-list');
const btnStrongest = document.getElementById('btn-strongest');
const btnLowCal = document.getElementById('btn-lowcal');

// Metrics (Futuristic Cockpit elements)
const caffeineValue = document.getElementById('caffeine-value');
const caloriesValue = document.getElementById('calories-value');
const energyBadge = document.getElementById('energy-badge');
const caffeineRing = document.getElementById('caffeine-ring');
const caffeineBarFill = document.getElementById('caffeine-bar-fill');
const caloriesBarFill = document.getElementById('calories-bar-fill');
const fdaPercentage = document.getElementById('fda-percentage');

// Application State
let drinksData = [];
let selectedDrink = null;
let selectedSize = 'small';
let selectedShots = 0;
let favorites = [];
let isLowCalFilterActive = false;
let highlightedIndex = -1;

// Storage abstraction (supports chrome/firefox extensions or standard localStorage for web viewing)
const storage = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local)
  ? {
      get: (key) => new Promise((resolve) => chrome.storage.local.get(key, (res) => resolve(res[key]))),
      set: (key, value) => new Promise((resolve) => chrome.storage.local.set({ [key]: value }, resolve))
    }
  : {
      get: async (key) => {
        const val = localStorage.getItem(key);
        return val ? JSON.parse(val) : null;
      },
      set: async (key, value) => {
        localStorage.setItem(key, JSON.stringify(value));
      }
    };

// Initialize Application
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // 1. Fetch drinks data
    const response = await fetch('../data/drinks.json');
    if (!response.ok) throw new Error('Failed to fetch drinks data');
    const data = await response.json();
    drinksData = data.drinks;

    // 2. Load favorites
    await loadFavorites();

    // 3. Set initial state (select first drink)
    if (drinksData.length > 0) {
      selectDrink(drinksData[0]);
    }

    // 4. Register event listeners
    initEventListeners();
  } catch (error) {
    console.error('Initialization error:', error);
  }
});

// Event Listeners setup
function initEventListeners() {
  // Dropdown visibility toggles
  drinkSearch.addEventListener('click', () => showDropdown());
  dropdownArrow.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleDropdown();
  });

  // Search input typing
  drinkSearch.addEventListener('input', () => {
    showDropdown();
    renderDropdownItems();
  });

  // Keyboard navigation inside dropdown search
  drinkSearch.addEventListener('keydown', handleSearchKeydown);

  // Close dropdown on clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.custom-select-container')) {
      hideDropdown();
    }
  });

  // Size Segment controls
  sizeControl.addEventListener('click', (e) => {
    const btn = e.target.closest('.segment-btn');
    if (!btn) return;
    
    // Deactivate previous active size button
    sizeControl.querySelectorAll('.segment-btn').forEach(b => b.classList.remove('active'));
    // Activate clicked button
    btn.classList.add('active');
    selectedSize = btn.dataset.size;
    updateResults();
  });

  // Shots Segment controls
  shotsControl.addEventListener('click', (e) => {
    const btn = e.target.closest('.segment-btn');
    if (!btn) return;

    // Deactivate previous active shots button
    shotsControl.querySelectorAll('.segment-btn').forEach(b => b.classList.remove('active'));
    // Activate clicked button
    btn.classList.add('active');
    selectedShots = parseInt(btn.dataset.shots, 10);
    updateResults();
  });

  // Favorite button click
  favoriteToggle.addEventListener('click', toggleFavorite);

  // Quick filters
  btnStrongest.addEventListener('click', selectStrongestDrink);
  btnLowCal.addEventListener('click', toggleLowCalorieFilter);
}

// Render Dropdown List
function renderDropdownItems() {
  drinksDropdown.innerHTML = '';
  const query = drinkSearch.value.toLowerCase().trim();

  // Filter drinks based on search and low calorie filter
  const filtered = drinksData.filter(drink => {
    const matchesSearch = drink.name.toLowerCase().includes(query) || 
                          drink.description.toLowerCase().includes(query) ||
                          drink.type.toLowerCase().includes(query);
                          
    if (isLowCalFilterActive) {
      // Low calorie filter active: only show drinks with small size < 150 kcal
      const isLowCal = drink.sizes.small.calories < 150;
      return matchesSearch && isLowCal;
    }
    
    return matchesSearch;
  });

  if (filtered.length === 0) {
    const noResult = document.createElement('div');
    noResult.className = 'dropdown-item';
    noResult.style.cursor = 'default';
    noResult.style.textAlign = 'center';
    noResult.style.color = 'var(--text-gray)';
    noResult.innerHTML = '<strong>No drinks found</strong>';
    drinksDropdown.appendChild(noResult);
    highlightedIndex = -1;
    return;
  }

  filtered.forEach((drink, index) => {
    const item = document.createElement('div');
    item.className = 'dropdown-item';
    if (index === highlightedIndex) {
      item.classList.add('highlighted');
    }
    
    // Highlight match in name if query exists
    let displayName = drink.name;
    if (query) {
      const reg = new RegExp(`(${query})`, 'gi');
      displayName = drink.name.replace(reg, '<mark>$1</mark>');
    }

    item.innerHTML = `
      <div class="dropdown-item-title">
        <span>${displayName}</span>
        <span class="dropdown-item-type">${drink.type}</span>
      </div>
      <div class="dropdown-item-desc">${drink.description}</div>
    `;

    item.addEventListener('click', () => {
      selectDrink(drink);
      hideDropdown();
    });

    drinksDropdown.appendChild(item);
  });
}

// Dropdown Helper Functions
function showDropdown() {
  drinksDropdown.classList.remove('hidden');
  dropdownArrow.classList.add('open');
  highlightedIndex = -1;
  renderDropdownItems();
}

function hideDropdown() {
  drinksDropdown.classList.add('hidden');
  dropdownArrow.classList.remove('open');
  drinkSearch.blur();
}

function toggleDropdown() {
  if (drinksDropdown.classList.contains('hidden')) {
    showDropdown();
  } else {
    hideDropdown();
  }
}

// Keyboard Navigation for Combobox Search
function handleSearchKeydown(e) {
  if (drinksDropdown.classList.contains('hidden')) {
    if (e.key === 'ArrowDown' || e.key === 'Enter') {
      showDropdown();
      e.preventDefault();
    }
    return;
  }

  const items = drinksDropdown.querySelectorAll('.dropdown-item');
  if (items.length === 0) return;

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    highlightedIndex = (highlightedIndex + 1) % items.length;
    renderDropdownItems();
    scrollHighlightedIntoView();
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    highlightedIndex = (highlightedIndex - 1 + items.length) % items.length;
    renderDropdownItems();
    scrollHighlightedIntoView();
  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (highlightedIndex >= 0 && highlightedIndex < items.length) {
      // Find the drink object in the filtered list
      const query = drinkSearch.value.toLowerCase().trim();
      const filtered = drinksData.filter(drink => {
        const matchesSearch = drink.name.toLowerCase().includes(query) || 
                              drink.description.toLowerCase().includes(query);
        if (isLowCalFilterActive) {
          return matchesSearch && drink.sizes.small.calories < 150;
        }
        return matchesSearch;
      });
      if (filtered[highlightedIndex]) {
        selectDrink(filtered[highlightedIndex]);
        hideDropdown();
      }
    }
  } else if (e.key === 'Escape') {
    hideDropdown();
  }
}

function scrollHighlightedIntoView() {
  const container = drinksDropdown;
  const highlighted = container.querySelector('.dropdown-item.highlighted');
  if (!highlighted) return;

  const containerTop = container.scrollTop;
  const containerBottom = containerTop + container.clientHeight;
  const elemTop = highlighted.offsetTop;
  const elemBottom = elemTop + highlighted.clientHeight;

  if (elemTop < containerTop) {
    container.scrollTop = elemTop;
  } else if (elemBottom > containerBottom) {
    container.scrollTop = elemBottom - container.clientHeight;
  }
}

// Select Drink
function selectDrink(drink) {
  selectedDrink = drink;
  drinkSearch.value = drink.name;
  updateResults();
}

// Update Caffeine and Calories Results
function updateResults() {
  if (!selectedDrink) return;

  const result = calculateCaffeineAndCalories(selectedDrink, selectedSize, selectedShots);

  // Update UI values
  caffeineValue.innerHTML = `${result.caffeine}<span class="metric-unit">mg</span>`;
  caloriesValue.innerHTML = `${result.calories}<span class="metric-unit">kcal</span>`;

  // Energy badge update
  energyBadge.textContent = result.energyLevel;
  
  // Reset previous energy level classes
  energyBadge.className = 'badge energy-badge';
  const levelClass = result.energyLevel.toLowerCase();
  energyBadge.classList.add(levelClass);

  // Update Circular Progress Ring
  const fdaLimit = 400; // mg
  const percentage = Math.min((result.caffeine / fdaLimit) * 100, 100);
  
  // Circumference of radius 38 circle is 2*pi*38 = 238.76
  const circ = 238.76;
  const offset = circ - (percentage / 100) * circ;
  
  caffeineRing.style.strokeDashoffset = offset;
  caffeineRing.className.baseVal = `meter-progress ${levelClass}`;

  // Update Metric fill bars
  if (caffeineBarFill) {
    caffeineBarFill.style.width = `${percentage}%`;
    caffeineBarFill.style.backgroundColor = `var(--energy-${levelClass})`;
    caffeineBarFill.style.boxShadow = `0 0 6px var(--energy-${levelClass})`;
  }
  if (caloriesBarFill) {
    const calPercentage = Math.min((result.calories / 1000) * 100, 100);
    caloriesBarFill.style.width = `${calPercentage}%`;
  }
  if (fdaPercentage) {
    fdaPercentage.textContent = `${Math.round((result.caffeine / fdaLimit) * 100)}%`;
    fdaPercentage.style.color = `var(--energy-${levelClass})`;
  }

  // Check if current drink/size/shots config is favorited
  checkFavoriteState();
}

// Favorites Logic
async function loadFavorites() {
  favorites = await storage.get('favorites') || [];
  renderFavorites();
}

function checkFavoriteState() {
  if (!selectedDrink) return;
  const exists = favorites.some(fav => 
    fav.drinkId === selectedDrink.id && 
    fav.size === selectedSize && 
    fav.shots === selectedShots
  );
  if (exists) {
    favoriteToggle.classList.add('active');
  } else {
    favoriteToggle.classList.remove('active');
  }
}

async function toggleFavorite() {
  if (!selectedDrink) return;

  const favIndex = favorites.findIndex(fav => 
    fav.drinkId === selectedDrink.id && 
    fav.size === selectedSize && 
    fav.shots === selectedShots
  );

  if (favIndex > -1) {
    // Remove from favorites
    favorites.splice(favIndex, 1);
  } else {
    // Add to favorites
    const newFavorite = {
      id: Date.now().toString(),
      drinkId: selectedDrink.id,
      drinkName: selectedDrink.name,
      size: selectedSize,
      shots: selectedShots
    };
    favorites.push(newFavorite);
  }

  await storage.set('favorites', favorites);
  renderFavorites();
  checkFavoriteState();
}

function renderFavorites() {
  favoritesList.innerHTML = '';
  
  if (favorites.length === 0) {
    favoritesSection.classList.add('hidden');
    return;
  }

  favoritesSection.classList.remove('hidden');

  favorites.forEach(fav => {
    const pill = document.createElement('div');
    pill.className = 'fav-pill';
    
    let sizeAbbr = fav.size === 'small' ? 'S' : fav.size === 'medium' ? 'M' : 'L';
    let shotInfo = fav.shots > 0 ? ` +${fav.shots}Sh` : '';
    
    pill.innerHTML = `
      <span>${fav.drinkName} (${sizeAbbr}${shotInfo})</span>
      <button class="btn-remove-fav" data-id="${fav.id}" title="Remove favorite">×</button>
    `;

    // Click pill to load configuration
    pill.addEventListener('click', (e) => {
      if (e.target.closest('.btn-remove-fav')) return;
      loadFavoriteConfig(fav);
    });

    // Remove favorite click
    const btnRemove = pill.querySelector('.btn-remove-fav');
    btnRemove.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btnRemove.dataset.id;
      favorites = favorites.filter(f => f.id !== id);
      await storage.set('favorites', favorites);
      renderFavorites();
      checkFavoriteState();
    });

    favoritesList.appendChild(pill);
  });
}

function loadFavoriteConfig(fav) {
  // 1. Find drink
  const drink = drinksData.find(d => d.id === fav.drinkId);
  if (!drink) return;

  selectedSize = fav.size;
  selectedShots = fav.shots;

  // 2. Update dropdown input UI
  selectDrink(drink);

  // 3. Update size pills
  sizeControl.querySelectorAll('.segment-btn').forEach(btn => {
    if (btn.dataset.size === selectedSize) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // 4. Update shots pills
  shotsControl.querySelectorAll('.segment-btn').forEach(btn => {
    if (parseInt(btn.dataset.shots, 10) === selectedShots) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  updateResults();
}

// Quick Actions
function selectStrongestDrink() {
  // Find drink with highest base caffeine (Cold Brew is 400mg in large)
  // And apply double shots (+2 espresso shots)
  
  let maxCaffeineDrink = null;
  let maxCaffeine = -1;

  drinksData.forEach(drink => {
    if (drink.sizes.large && drink.sizes.large.caffeine > maxCaffeine) {
      maxCaffeine = drink.sizes.large.caffeine;
      maxCaffeineDrink = drink;
    }
  });

  if (maxCaffeineDrink) {
    selectedSize = 'large';
    selectedShots = 2; // Maximum extra shots
    
    // Update active visual states
    sizeControl.querySelectorAll('.segment-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.size === 'large');
    });

    shotsControl.querySelectorAll('.segment-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.shots === '2');
    });

    // Make sure search filter matches
    isLowCalFilterActive = false;
    btnLowCal.classList.remove('active');
    
    selectDrink(maxCaffeineDrink);
  }
}

function toggleLowCalorieFilter() {
  isLowCalFilterActive = !isLowCalFilterActive;
  btnLowCal.classList.toggle('active', isLowCalFilterActive);

  // Re-render dropdown list options
  renderDropdownItems();

  // If currently selected drink is not low calorie, select the first matching low calorie drink
  if (isLowCalFilterActive && selectedDrink && selectedDrink.sizes.small.calories >= 150) {
    const firstLowCal = drinksData.find(d => d.sizes.small.calories < 150);
    if (firstLowCal) {
      selectDrink(firstLowCal);
    }
  }
}
