import zlib
import struct
import os

def draw_icon(width, height):
    # Background: deep charcoal black (15, 17, 21)
    bg_color = (15, 17, 21)
    # Icon foreground (7): neon electric blue (0, 194, 255)
    fg_color = (0, 194, 255)
    
    raw_data = b""
    for y in range(height):
        raw_data += b"\x00"  # Filter type 0
        v = y / (height - 1) if height > 1 else 0
        for x in range(width):
            u = x / (width - 1) if width > 1 else 0
            
            # Check if inside '7'
            is_7 = False
            # Top bar
            if 0.22 <= v <= 0.36 and 0.25 <= u <= 0.75:
                is_7 = True
            # Diagonal stroke
            elif 0.36 < v <= 0.8:
                # Interpolated u position for the diagonal line from (0.75, 0.36) to (0.35, 0.8)
                target_u = 0.35 + (0.75 - 0.35) * (0.8 - v) / (0.8 - 0.36)
                if abs(u - target_u) <= 0.08:
                    is_7 = True
                    
            color = fg_color if is_7 else bg_color
            raw_data += bytes(color)
            
    # PNG assembly
    png = b"\x89PNG\r\n\x1a\n"
    
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    png += struct.pack(">I", 13) + b"IHDR" + ihdr + struct.pack(">I", zlib.crc32(b"IHDR" + ihdr))
    
    compressed = zlib.compress(raw_data)
    png += struct.pack(">I", len(compressed)) + b"IDAT" + compressed + struct.pack(">I", zlib.crc32(b"IDAT" + compressed))
    
    png += struct.pack(">I", 0) + b"IEND" + struct.pack(">I", zlib.crc32(b"IEND"))
    return png

def save_icon(path, size):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(draw_icon(size, size))

if __name__ == "__main__":
    sizes = [16, 32, 48, 128]
    # We will write to shared/assets/
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    for size in sizes:
        save_icon(os.path.join(SCRIPT_DIR, "shared", "assets", f"icon{size}.png"), size)
    print("Icons generated successfully!")
