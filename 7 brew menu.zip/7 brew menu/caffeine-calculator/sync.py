import os
import shutil

# Get the directory of the script (c:\Users\Danyal Kausar\Pictures\7 brew menu\extensions)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def sync_shared_to_browser(browser_name):
    print(f"Syncing shared resources to {browser_name}...")
    dest_base = os.path.join(SCRIPT_DIR, browser_name)
    
    # Ensure browser folder exists
    os.makedirs(dest_base, exist_ok=True)
    
    shared_dirs = ["popup", "data", "assets", "logic"]
    
    for d in shared_dirs:
        src = os.path.join(SCRIPT_DIR, "shared", d)
        dest = os.path.join(dest_base, d)
        
        # Remove old directory if it exists
        if os.path.exists(dest):
            shutil.rmtree(dest)
            
        # Copy directory if it exists in shared
        if os.path.exists(src):
            shutil.copytree(src, dest)
            print(f"  Copied {src} -> {dest}")
        else:
            print(f"  Warning: Source {src} does not exist.")

if __name__ == "__main__":
    browsers = ["chrome", "edge", "firefox"]
    for browser in browsers:
        sync_shared_to_browser(browser)
    print("Sync complete! All browser folders are ready to run.")
